export const environment = {
  production: true,
  //api_url: 'http://weonws.com/sellers/public/api/',
  //image_url:'http://weonws.com/sellers/public/uploads/',

  //api_url: 'http://18.220.111.165/tms/public/api/',
 // image_url:'http://18.220.111.165/tms/public/uploads/',

  api_url: 'https://store.safeertyres.com/storeApp/public/api/',
  image_url:'https://store.safeertyres.com/storeApp/public/uploads/',

};
