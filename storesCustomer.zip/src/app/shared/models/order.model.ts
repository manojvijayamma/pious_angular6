export class Order {
    title: string;
    category_title: string;
    type_title: string;
    model: string;
    price: string;
}
