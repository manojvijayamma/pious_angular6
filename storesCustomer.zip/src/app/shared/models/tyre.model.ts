export class Tyre {
    title: string;
    category_title: string;
    type_title: string;
    model: string;
    price: string;
}
